public class FinancialForecasting {

    /**
     * Recursive method to calculate the future value of an investment.
     * 
     * @param currentValue The current value of the investment.
     * @param growthRate The growth rate per period.
     * @param periods The number of periods for forecasting.
     * @return The future value of the investment.
     */
    public static double calculateFutureValue(double currentValue, double growthRate, int periods) {
        // Base case: No periods left to forecast
        if (periods == 0) {
            return currentValue;
        }
        // Recursive case: Calculate future value for the next period
        return calculateFutureValue(currentValue * (1 + growthRate), growthRate, periods - 1);
    }

    public static void main(String[] args) {
        double initialValue = 1000; // Initial investment
        double growthRate = 0.05;   // Growth rate (5%)
        int periods = 10;           // Number of periods

        double futureValue = calculateFutureValue(initialValue, growthRate, periods);
        System.out.println("Future Value: $" + futureValue);
    }
}
