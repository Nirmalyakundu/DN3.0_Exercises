public class SearchAlgorithms_linear {
    public static Product linearSearch(Product[] products, String productId) {
         for (Product product : products) {
             if (product.getProductId().equals(productId)) {
                 return product;
             }
   }
         return null; // Product not found
     }
 }
 
